"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
var path = require('path');
var url = require('url');
var fs = require('fs');
const tl = require('vsts-task-lib/task');
const WebApi_1 = require('vso-node-api/WebApi');
const engine = require("artifact-engine/Engine");
const providers = require("artifact-engine/Providers");
const webHandlers = require("artifact-engine/Providers/typed-rest-client/Handlers");
tl.setResourcePath(path.join(__dirname, 'task.json'));
var taskJson = require('./task.json');
const area = 'DownloadExternalBuildArtifacts';
function getDefaultProps() {
    var hostType = (tl.getVariable('SYSTEM.HOSTTYPE') || "").toLowerCase();
    return {
        hostType: hostType,
        definitionName: '[NonEmail:' + (hostType === 'release' ? tl.getVariable('RELEASE.DEFINITIONNAME') : tl.getVariable('BUILD.DEFINITIONNAME')) + ']',
        processId: hostType === 'release' ? tl.getVariable('RELEASE.RELEASEID') : tl.getVariable('BUILD.BUILDID'),
        processUrl: hostType === 'release' ? tl.getVariable('RELEASE.RELEASEWEBURL') : (tl.getVariable('SYSTEM.TEAMFOUNDATIONSERVERURI') + tl.getVariable('SYSTEM.TEAMPROJECT') + '/_build?buildId=' + tl.getVariable('BUILD.BUILDID')),
        taskDisplayName: tl.getVariable('TASK.DISPLAYNAME'),
        jobid: tl.getVariable('SYSTEM.JOBID'),
        agentVersion: tl.getVariable('AGENT.VERSION'),
        agentOS: tl.getVariable('AGENT.OS'),
        agentName: tl.getVariable('AGENT.NAME'),
        version: taskJson.version
    };
}
function publishEvent(feature, properties) {
    try {
        var splitVersion = (process.env.AGENT_VERSION || '').split('.');
        var major = parseInt(splitVersion[0] || '0');
        var minor = parseInt(splitVersion[1] || '0');
        let telemetry = '';
        if (major > 2 || (major == 2 && minor >= 120)) {
            telemetry = `##vso[telemetry.publish area=${area};feature=${feature}]${JSON.stringify(Object.assign(getDefaultProps(), properties))}`;
        }
        else {
            if (feature === 'reliability') {
                let reliabilityData = properties;
                telemetry = "##vso[task.logissue type=error;code=" + reliabilityData.issueType + ";agentVersion=" + tl.getVariable('Agent.Version') + ";taskId=" + area + "-" + JSON.stringify(taskJson.version) + ";]" + reliabilityData.errorMessage;
            }
        }
        console.log(telemetry);
        ;
    }
    catch (err) {
        tl.warning("Failed to log telemetry, error: " + err);
    }
}
function main() {
    return __awaiter(this, void 0, Promise, function* () {
        var promise = new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
            var connection = tl.getInput("connection", true);
            var projectId = tl.getInput("project", true);
            var definitionId = tl.getInput("definition", true);
            var buildId = tl.getInput("version", true);
            var itemPattern = tl.getInput("itemPattern", true);
            var downloadPath = tl.getInput("downloadPath", true);
            var endpointUrl = tl.getEndpointUrl(connection, false);
            var username = tl.getEndpointAuthorizationParameter(connection, 'username', true);
            var accessToken = tl.getEndpointAuthorizationParameter(connection, 'apitoken', true)
                || tl.getEndpointAuthorizationParameter(connection, 'password', true);
            var credentialHandler = WebApi_1.getBasicHandler(username, accessToken);
            var vssConnection = new WebApi_1.WebApi(endpointUrl, credentialHandler);
            var debugMode = tl.getVariable('System.Debug');
            var verbose = debugMode ? debugMode.toLowerCase() != 'false' : false;
            var parallelLimit = +tl.getVariable("release.artifact.download.parallellimit");
            var templatePath = path.join(__dirname, 'vsts.handlebars');
            var buildApi = vssConnection.getBuildApi();
            var artifacts = yield executeWithRetries("getArtifacts", () => buildApi.getArtifacts(parseInt(buildId), projectId), 3).catch((reason) => {
                reject(reason);
            });
            if (artifacts) {
                var downloadPromises = [];
                console.log("Linked artifacts count: " + artifacts.length);
                artifacts.forEach(function (artifact, index, artifacts) {
                    return __awaiter(this, void 0, void 0, function* () {
                        let downloaderOptions = new engine.ArtifactEngineOptions();
                        downloaderOptions.itemPattern = itemPattern;
                        downloaderOptions.verbose = verbose;
                        if (parallelLimit) {
                            downloaderOptions.parallelProcessingLimit = parallelLimit;
                        }
                        if (artifact.resource.type.toLowerCase() === "container") {
                            let downloader = new engine.ArtifactEngine();
                            var containerParts = artifact.resource.data.split('/', 3);
                            if (containerParts.length !== 3) {
                                throw new Error(tl.loc("FileContainerInvalidArtifactData"));
                            }
                            var containerId = parseInt(containerParts[1]);
                            var containerPath = containerParts[2];
                            var itemsUrl = endpointUrl + "/_apis/resources/Containers/" + containerId + "?itemPath=" + encodeURIComponent(containerPath) + "&isShallow=true";
                            itemsUrl = itemsUrl.replace(/([^:]\/)\/+/g, "$1");
                            console.log(tl.loc("DownloadArtifacts", itemsUrl));
                            var variables = {};
                            var handler = username ? new webHandlers.BasicCredentialHandler(username, accessToken) : new webHandlers.PersonalAccessTokenCredentialHandler(accessToken);
                            var webProvider = new providers.WebProvider(itemsUrl, templatePath, variables, handler);
                            var fileSystemProvider = new providers.FilesystemProvider(downloadPath);
                            downloadPromises.push(downloader.processItems(webProvider, fileSystemProvider, downloaderOptions).catch((reason) => {
                                reject(reason);
                            }));
                        }
                        else if (artifact.resource.type.toLowerCase() === "filepath") {
                            let downloader = new engine.ArtifactEngine();
                            let downloadUrl = artifact.resource.data;
                            let artifactLocation = downloadUrl + '/' + artifact.name;
                            if (!fs.existsSync(artifactLocation)) {
                                console.log(tl.loc("ArtifactNameDirectoryNotFound", artifactLocation, downloadUrl));
                                artifactLocation = downloadUrl;
                            }
                            console.log(tl.loc("DownloadArtifacts", artifactLocation));
                            var fileShareProvider = new providers.FilesystemProvider(artifactLocation);
                            var fileSystemProvider = new providers.FilesystemProvider(downloadPath + '\\' + artifact.name);
                            downloadPromises.push(downloader.processItems(fileShareProvider, fileSystemProvider, downloaderOptions).catch((reason) => {
                                reject(reason);
                            }));
                        }
                        else {
                            console.log(tl.loc('UnsupportedArtifactType', artifact.resource.type));
                        }
                    });
                });
                Promise.all(downloadPromises).then(() => {
                    console.log(tl.loc('ArtifactsSuccessfullyDownloaded', downloadPath));
                    resolve();
                }).catch((error) => {
                    reject(error);
                });
            }
        }));
        return promise;
    });
}
function executeWithRetries(operationName, operation, retryCount) {
    var executePromise = new Promise((resolve, reject) => {
        executeWithRetriesImplementation(operationName, operation, retryCount, resolve, reject);
    });
    return executePromise;
}
function executeWithRetriesImplementation(operationName, operation, currentRetryCount, resolve, reject) {
    operation().then((result) => {
        resolve(result);
    }).catch((error) => {
        if (currentRetryCount <= 0) {
            tl.error(tl.loc("OperationFailed", operationName, error));
            console.log(error);
            tl.debug(error);
            reject(error);
        }
        else {
            console.log(tl.loc('RetryingOperation', operationName, currentRetryCount));
            console.log(error);
            tl.debug(error);
            currentRetryCount = currentRetryCount - 1;
            setTimeout(() => executeWithRetriesImplementation(operationName, operation, currentRetryCount, resolve, reject), 4 * 1000);
        }
    });
}
main()
    .then((result) => tl.setResult(tl.TaskResult.Succeeded, ""))
    .catch((err) => {
    publishEvent('reliability', { issueType: 'error', errorMessage: JSON.stringify(err, Object.getOwnPropertyNames(err)) });
    tl.setResult(tl.TaskResult.Failed, err);
});
