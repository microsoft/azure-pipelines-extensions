import * as models from "../Models";
export declare class ArtifactItemStore {
    _downloadTickets: models.ArtifactDownloadTicket[];
    _hasDownloadFailed: boolean;
    addItem(item: models.ArtifactItem): void;
    addItems(items: models.ArtifactItem[]): void;
    getTickets(): models.ArtifactDownloadTicket[];
    itemsPendingProcessing(): boolean;
    getNextItemToProcess(): models.ArtifactItem;
    updateState(item: models.ArtifactItem, state: models.TicketState): void;
    getRootLocation(): string;
    increaseRetryCount(item: models.ArtifactItem): void;
    updateDownloadSize(item: models.ArtifactItem, downloadSizeInBytes: number): void;
    updateFileSize(item: models.ArtifactItem, fileSizeInBytes: number): void;
    size(): number;
    flush(): void;
    hasDownloadFailed(): boolean;
}
