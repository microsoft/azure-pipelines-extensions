"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArtifactItemStore = void 0;
const models = require("../Models");
class ArtifactItemStore {
    constructor() {
        this._downloadTickets = [];
        this._hasDownloadFailed = false;
    }
    addItem(item) {
        if (this._downloadTickets.find(x => x.artifactItem.path === item.path)) {
            return;
        }
        var artifactDownloadTicket = {
            artifactItem: item,
            state: models.TicketState.InQueue,
            startTime: undefined,
            finishTime: undefined,
            retryCount: 0,
            downloadSizeInBytes: 0,
            fileSizeInBytes: 0
        };
        this._downloadTickets.push(artifactDownloadTicket);
    }
    addItems(items) {
        items.map((value, index) => {
            this.addItem(value);
        });
    }
    getTickets() {
        return this._downloadTickets;
    }
    itemsPendingProcessing() {
        var processingTickets = this._downloadTickets.filter(x => x.state === models.TicketState.Processing || x.state === models.TicketState.InQueue);
        return processingTickets.length != 0;
    }
    getNextItemToProcess() {
        var nextItemToProcess = this._downloadTickets.find(x => x.state === models.TicketState.InQueue);
        if (nextItemToProcess) {
            nextItemToProcess.state = models.TicketState.Processing;
            nextItemToProcess.startTime = new Date();
            return nextItemToProcess.artifactItem;
        }
        return undefined;
    }
    updateState(item, state) {
        var processedItem = this._downloadTickets.find(x => x.artifactItem.path === item.path);
        if (processedItem) {
            processedItem.state = state;
            if (state != models.TicketState.InQueue && state != models.TicketState.Processing) {
                processedItem.finishTime = new Date();
            }
            if (state === models.TicketState.Failed) {
                this._hasDownloadFailed = true;
            }
        }
    }
    getRootLocation() {
        var rootItem = this._downloadTickets.find(x => x.artifactItem.path === "");
        var rootLocation = '';
        if (rootItem && rootItem.artifactItem.metadata) {
            rootLocation = rootItem.artifactItem.metadata["downloadUrl"];
        }
        return rootLocation ? rootLocation : '';
    }
    increaseRetryCount(item) {
        var ticket = this._downloadTickets.find(x => x.artifactItem.path === item.path);
        if (ticket) {
            ticket.retryCount = ticket.retryCount + 1;
        }
    }
    updateDownloadSize(item, downloadSizeInBytes) {
        var ticket = this._downloadTickets.find(x => x.artifactItem.path === item.path);
        if (ticket) {
            ticket.downloadSizeInBytes = downloadSizeInBytes;
        }
    }
    updateFileSize(item, fileSizeInBytes) {
        var ticket = this._downloadTickets.find(x => x.artifactItem.path === item.path);
        if (ticket) {
            ticket.fileSizeInBytes = fileSizeInBytes;
        }
    }
    size() {
        return this._downloadTickets.length;
    }
    flush() {
        this._downloadTickets = [];
        this._hasDownloadFailed = false;
    }
    hasDownloadFailed() {
        return this._hasDownloadFailed;
    }
}
exports.ArtifactItemStore = ArtifactItemStore;
//# sourceMappingURL=artifactItemStore.js.map