"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArtifactEngine = void 0;
const path = require("path");
var tl = require('azure-pipelines-task-lib/task');
const models = require("../Models");
const ci = require("./cilogger");
const artifactItemStore_1 = require("../Store/artifactItemStore");
const artifactEngineOptions_1 = require("./artifactEngineOptions");
const logger_1 = require("./logger");
const worker_1 = require("./worker");
class ArtifactEngine {
    constructor() {
        this.artifactItemStore = new artifactItemStore_1.ArtifactItemStore();
    }
    processItems(sourceProvider, destProvider, artifactEngineOptions) {
        var artifactDownloadTicketsPromise = new Promise((resolve, reject) => {
            const workers = [];
            artifactEngineOptions = artifactEngineOptions || new artifactEngineOptions_1.ArtifactEngineOptions();
            this.createPatternList(artifactEngineOptions);
            this.artifactItemStore.flush();
            logger_1.Logger.verbose = artifactEngineOptions.verbose;
            this.logger = new logger_1.Logger(this.artifactItemStore);
            this.logger.logProgress();
            sourceProvider.artifactItemStore = this.artifactItemStore;
            destProvider.artifactItemStore = this.artifactItemStore;
            sourceProvider.getRootItems().then((itemsToProcess) => {
                this.artifactItemStore.addItems(itemsToProcess);
                for (let i = 0; i < artifactEngineOptions.parallelProcessingLimit; ++i) {
                    var worker = new worker_1.Worker(i + 1, item => this.processArtifactItem(sourceProvider, item, destProvider, artifactEngineOptions), () => this.artifactItemStore.getNextItemToProcess(), () => !this.artifactItemStore.itemsPendingProcessing(), () => this.artifactItemStore.hasDownloadFailed());
                    workers.push(worker.init());
                }
                Promise.all(workers).then(() => {
                    this.logger.logSummary();
                    sourceProvider.dispose();
                    destProvider.dispose();
                    resolve(this.artifactItemStore.getTickets());
                }, (err) => {
                    ci.publishEvent('reliability', { issueType: 'error', errorMessage: JSON.stringify(err, Object.getOwnPropertyNames(err)) });
                    sourceProvider.dispose();
                    destProvider.dispose();
                    reject(err);
                });
            }, (err) => {
                ci.publishEvent('reliability', { issueType: 'error', errorMessage: JSON.stringify(err, Object.getOwnPropertyNames(err)) });
                sourceProvider.dispose();
                destProvider.dispose();
                reject(err);
            });
        });
        return artifactDownloadTicketsPromise;
    }
    processArtifactItem(sourceProvider, item, destProvider, artifactEngineOptions) {
        return new Promise((resolve, reject) => {
            this.processArtifactItemImplementation(sourceProvider, item, destProvider, artifactEngineOptions, resolve, reject);
        });
    }
    processArtifactItemImplementation(sourceProvider, item, destProvider, artifactEngineOptions, resolve, reject, retryCount) {
        var retryIfRequired = (err) => {
            if (retryCount === artifactEngineOptions.retryLimit - 1) {
                this.artifactItemStore.updateState(item, models.TicketState.Failed);
                reject(err);
            }
            else {
                this.artifactItemStore.increaseRetryCount(item);
                logger_1.Logger.logMessage(tl.loc("RetryingDownload", item.path, (retryCount + 1)));
                setTimeout(() => this
                    .processArtifactItemImplementation(sourceProvider, item, destProvider, artifactEngineOptions, resolve, reject, retryCount + 1), this.getRetryIntervalInSeconds(artifactEngineOptions.retryIntervalInSeconds, retryCount) * 1000);
            }
        };
        retryCount = retryCount ? retryCount : 0;
        if (item.itemType === models.ItemType.File) {
            var pathToMatch = item.path.replace(/\\/g, '/');
            var matchOptions = {
                debug: false,
                nobrace: true,
                noglobstar: false,
                dot: true,
                noext: false,
                nocase: false,
                nonull: false,
                matchBase: false,
                nocomment: false,
                nonegate: false,
                flipNegate: false
            };
            if (tl.match([pathToMatch], this.patternList, null, matchOptions).length > 0) {
                logger_1.Logger.logInfo("Processing " + item.path);
                sourceProvider.getArtifactItem(item).then((contentStream) => {
                    logger_1.Logger.logInfo("Got download stream for item: " + item.path);
                    destProvider.putArtifactItem(item, contentStream)
                        .then((item) => {
                        this.artifactItemStore.updateState(item, models.TicketState.Processed);
                        resolve();
                    }, (err) => {
                        logger_1.Logger.logInfo("Error placing file " + item.path + ": " + err);
                        retryIfRequired(err);
                    });
                }, (err) => {
                    logger_1.Logger.logInfo("Error getting file " + item.path + ": " + err);
                    retryIfRequired(err);
                });
            }
            else {
                logger_1.Logger.logMessage(tl.loc("SkippingItem", pathToMatch));
                this.artifactItemStore.updateState(item, models.TicketState.Skipped);
                resolve();
            }
        }
        else {
            sourceProvider.getArtifactItems(item).then((items) => {
                items = items.map((value, index) => {
                    if (!value.path.toLowerCase().startsWith(item.path.toLowerCase())) {
                        value.path = path.join(item.path, value.path);
                    }
                    return value;
                });
                if (items.length > 0) {
                    this.artifactItemStore.addItems(items);
                    this.artifactItemStore.updateState(item, models.TicketState.Processed);
                }
                else {
                    destProvider.putArtifactItem(item, null)
                        .then((item) => {
                        this.artifactItemStore.updateState(item, models.TicketState.Processed);
                        resolve();
                    }, (err) => {
                        logger_1.Logger.logInfo("Error creating folder " + item.path + ": " + err);
                        retryIfRequired(err);
                    });
                }
                logger_1.Logger.logInfo("Enqueued " + items.length + " for processing.");
                resolve();
            }, (err) => {
                logger_1.Logger.logInfo("Error getting " + item.path + ":" + err);
                retryIfRequired(err);
            });
        }
    }
    getRetryIntervalInSeconds(baseRetryInterval, retryCount) {
        let MaxRetryLimitInSeconds = 360;
        var exponentialBackOff = baseRetryInterval * Math.pow(3, (retryCount + 1));
        return exponentialBackOff < MaxRetryLimitInSeconds ? exponentialBackOff : MaxRetryLimitInSeconds;
    }
    createPatternList(artifactEngineOptions) {
        if (!artifactEngineOptions.itemPattern) {
            this.patternList = ['**'];
        }
        else {
            this.patternList = artifactEngineOptions.itemPattern.split('\n');
        }
    }
}
exports.ArtifactEngine = ArtifactEngine;
tl.setResourcePath(path.join(path.dirname(__dirname), 'lib.json'));
process.on('unhandledRejection', (err) => {
    ci.publishEvent('reliability', { issueType: 'unhandledRejection', errorMessage: JSON.stringify(err, Object.getOwnPropertyNames(err)) });
    logger_1.Logger.logError(tl.loc("UnhandledRejection", err));
    throw err;
});
process.on('uncaughtException', (err) => {
    ci.publishEvent('reliability', { issueType: 'uncaughtException', errorMessage: JSON.stringify(err, Object.getOwnPropertyNames(err)) });
    logger_1.Logger.logError(tl.loc("UnhandledException", err));
    throw err;
});
//# sourceMappingURL=artifactEngine.js.map