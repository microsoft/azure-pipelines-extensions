export declare class Worker<T> {
    private execute;
    private getNextItem;
    private canExit;
    private hasDownloadFailed;
    private id;
    constructor(id: number, execute: (item: T) => Promise<void>, getNextItem: () => T, canExit: () => boolean, hasDownloadFailed: () => boolean);
    init(): Promise<void>;
    spawnWorker(resolve: any, reject: any): void;
}
