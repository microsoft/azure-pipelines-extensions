"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logger = void 0;
const Models_1 = require("../Models");
const ticketState_1 = require("../Models/ticketState");
var tl = require('azure-pipelines-task-lib');
const ci = require("./cilogger");
class Logger {
    constructor(store) {
        this.store = store;
        this.startTime = new Date();
    }
    static logInfo(message) {
        tl.debug(message);
    }
    static logError(message) {
        tl.error(message);
    }
    static logMessage(message) {
        console.log(message);
    }
    logProgress() {
        if (Logger.verbose) {
            var progressLogger = () => __awaiter(this, void 0, void 0, function* () {
                return setTimeout(() => {
                    var tickets = this.store.getTickets();
                    var queuedItems = tickets.filter(x => x.state == ticketState_1.TicketState.InQueue);
                    var processingItems = tickets.filter(x => x.state == ticketState_1.TicketState.Processing);
                    var processedItems = tickets.filter(x => x.state == ticketState_1.TicketState.Processed);
                    var skippedItems = tickets.filter(x => x.state == ticketState_1.TicketState.Skipped);
                    var failedItems = tickets.filter(x => x.state == ticketState_1.TicketState.Failed);
                    var currentTime = new Date();
                    tl.debug("Total Items: " + tickets.length
                        + ", Processed: " + processedItems.length
                        + ", Processing: " + processingItems.length
                        + ", Queued: " + queuedItems.length
                        + ", Skipped: " + skippedItems.length
                        + ", Failed: " + failedItems.length
                        + ", Time elapsed: " + ((currentTime.valueOf() - this.startTime.valueOf()) / 1000) + "secs");
                    if (this.store.itemsPendingProcessing() && !this.store.hasDownloadFailed()) {
                        progressLogger();
                    }
                }, 5000);
            });
            progressLogger();
        }
    }
    logSummary() {
        var allTickets = this.store.getTickets();
        var fileTickets = allTickets.filter(x => x.artifactItem.itemType == Models_1.ItemType.File);
        var finishedItems = fileTickets.filter(x => x.state == ticketState_1.TicketState.Processed || x.state == ticketState_1.TicketState.Skipped || x.state == ticketState_1.TicketState.Failed);
        var processedItems = fileTickets.filter(x => x.state == ticketState_1.TicketState.Processed);
        var skippedItems = fileTickets.filter(x => x.state == ticketState_1.TicketState.Skipped);
        var failedItems = fileTickets.filter(x => x.state == ticketState_1.TicketState.Failed);
        var downloadSizeInBytes = 0;
        var fileSizeInBytes = 0;
        for (var ticket of fileTickets) {
            downloadSizeInBytes += ticket.downloadSizeInBytes;
            fileSizeInBytes += ticket.fileSizeInBytes;
        }
        var downloadSizeInMB = (downloadSizeInBytes / (1024 * 1024));
        var endTime = new Date();
        var downloadTime = (endTime.valueOf() - this.startTime.valueOf()) / 1000;
        console.log(tl.loc("DownloadSummary", fileTickets.length, processedItems.length, skippedItems.length, failedItems.length, downloadTime, (downloadSizeInMB > 1 ? downloadSizeInMB.toFixed(3) + "MB" : downloadSizeInBytes + "Bytes")));
        ci.publishEvent('performance', {
            location: this.store.getRootLocation(),
            total: allTickets.length,
            files: fileTickets.length,
            processed: processedItems.length,
            skipped: skippedItems.length,
            failed: failedItems.length,
            downloadTimeInSeconds: downloadTime,
            downloadSizeInBytes: downloadSizeInBytes,
            fileSizeInBytes: fileSizeInBytes
        });
        if (Logger.verbose) {
            tl.debug("Summary:");
            var pathLengths = finishedItems.map(x => x.artifactItem.path.length);
            var maxPathLength = pathLengths.reduce((a, b) => a > b ? a : b, 1);
            var fileHeader = this.padText("File", maxPathLength);
            var startTimeHeader = this.padText("Start Time", 25);
            var finishTimeHeader = this.padText("Finish Time", 25);
            var durationHeader = this.padText("Duration", 10);
            var stateHeader = this.padText("STATE", 10);
            tl.debug(this.padText("", maxPathLength + 25 + 25 + 10 + 10 + 15, '-'));
            tl.debug(`| ${fileHeader} | ${startTimeHeader} | ${finishTimeHeader} | ${durationHeader} | ${stateHeader}|`);
            tl.debug(this.padText("", maxPathLength + 25 + 25 + 10 + 10 + 15, '-'));
            fileTickets.forEach(ticket => {
                var duration = (ticket.finishTime.valueOf() - ticket.startTime.valueOf()) / 1000 + " secs";
                tl.debug("| " + this.padText(ticket.artifactItem.path, maxPathLength) + " | " + this.padText(ticket.startTime.toISOString(), 25) + " | " + this.padText(ticket.finishTime.toISOString(), 25) + " | " + this.padText(duration, 10) + " | " + this.padText(ticket.state.toString().toUpperCase(), 10) + "|");
                tl.debug(this.padText("", maxPathLength + 25 + 25 + 10 + 10 + 15, '-'));
            });
        }
    }
    padText(textToPad, maxTextLength, padChar) {
        var m = Math.max(maxTextLength - textToPad.length, 0);
        var pad = Array(parseInt("" + m) + 1).join(padChar || ' ');
        var paddedText = textToPad + pad;
        return paddedText;
    }
}
exports.Logger = Logger;
//# sourceMappingURL=logger.js.map