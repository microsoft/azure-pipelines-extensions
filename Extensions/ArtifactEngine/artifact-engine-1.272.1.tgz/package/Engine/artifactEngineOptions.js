"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArtifactEngineOptions = void 0;
class ArtifactEngineOptions {
    constructor() {
        this.retryLimit = 5;
        this.retryIntervalInSeconds = 5;
        this.fileProcessingTimeoutInMinutes = 5;
        this.parallelProcessingLimit = 4;
        this.itemPattern = '**';
        this.verbose = false;
    }
}
exports.ArtifactEngineOptions = ArtifactEngineOptions;
//# sourceMappingURL=artifactEngineOptions.js.map