import { ArtifactItemStore } from '../Store/artifactItemStore';
export declare class Logger {
    constructor(store: ArtifactItemStore);
    static logInfo(message: string): void;
    static logError(message: string): void;
    static logMessage(message: string): void;
    logProgress(): void;
    logSummary(): void;
    private padText;
    static verbose: boolean;
    private store;
    private startTime;
}
