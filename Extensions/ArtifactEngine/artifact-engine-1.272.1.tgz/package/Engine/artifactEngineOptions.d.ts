export declare class ArtifactEngineOptions {
    retryLimit: number;
    retryIntervalInSeconds: number;
    fileProcessingTimeoutInMinutes: number;
    parallelProcessingLimit: number;
    itemPattern: string;
    verbose: boolean;
}
