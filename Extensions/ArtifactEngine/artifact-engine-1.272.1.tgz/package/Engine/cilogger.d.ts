export declare function publishEvent(feature: any, properties: any | IReliabilityData): void;
export interface IReliabilityData {
    issueType: string;
    errorMessage: string;
    stack: string;
}
