"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Worker = void 0;
const logger_1 = require("./logger");
class Worker {
    constructor(id, execute, getNextItem, canExit, hasDownloadFailed) {
        this.id = id;
        this.execute = execute;
        this.getNextItem = getNextItem;
        this.canExit = canExit;
        this.hasDownloadFailed = hasDownloadFailed;
    }
    init() {
        var promise = new Promise((resolve, reject) => {
            this.spawnWorker(resolve, reject);
        });
        return promise;
    }
    spawnWorker(resolve, reject) {
        try {
            if (this.hasDownloadFailed()) {
                logger_1.Logger.logInfo(`Aborting respawning worker, as download failed for some file(s).`);
                return;
            }
            let item = this.getNextItem();
            if (!item && !this.canExit()) {
                logger_1.Logger.logInfo(`Nothing to process currently, respawing worker ${this.id} after 1 sec.`);
                setTimeout(() => this.spawnWorker(resolve, reject), 1000);
                return;
            }
            if (!item) {
                logger_1.Logger.logInfo(`Nothing more to process, exiting worker ${this.id}.`);
                resolve();
                return;
            }
            let executePromise = this.execute(item);
            executePromise.then(() => {
                logger_1.Logger.logInfo(`Nothing to process currently, respawing worker ${this.id} after 1 sec.`);
                this.spawnWorker(resolve, reject);
            }, (reason) => {
                reject(reason);
                return;
            });
        }
        catch (err) {
            reject(err);
        }
    }
}
exports.Worker = Worker;
//# sourceMappingURL=worker.js.map