import * as models from '../Models';
import { ArtifactEngineOptions } from "./artifactEngineOptions";
export declare class ArtifactEngine {
    processItems(sourceProvider: models.IArtifactProvider, destProvider: models.IArtifactProvider, artifactEngineOptions?: ArtifactEngineOptions): Promise<models.ArtifactDownloadTicket[]>;
    processArtifactItem(sourceProvider: models.IArtifactProvider, item: models.ArtifactItem, destProvider: models.IArtifactProvider, artifactEngineOptions: ArtifactEngineOptions): Promise<void>;
    processArtifactItemImplementation(sourceProvider: models.IArtifactProvider, item: models.ArtifactItem, destProvider: models.IArtifactProvider, artifactEngineOptions: ArtifactEngineOptions, resolve: any, reject: any, retryCount?: number): void;
    private getRetryIntervalInSeconds;
    createPatternList(artifactEngineOptions: ArtifactEngineOptions): void;
    private artifactItemStore;
    private logger;
    private patternList;
}
