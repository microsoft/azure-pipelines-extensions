"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArtifactDownloadTicket = void 0;
class ArtifactDownloadTicket {
}
exports.ArtifactDownloadTicket = ArtifactDownloadTicket;
//# sourceMappingURL=artifactDownloadTicket.js.map