"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArtifactItem = void 0;
class ArtifactItem {
    constructor() {
        this.metadata = {};
    }
}
exports.ArtifactItem = ArtifactItem;
//# sourceMappingURL=artifactItem.js.map