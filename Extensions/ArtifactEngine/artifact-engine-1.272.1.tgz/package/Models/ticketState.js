"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TicketState = void 0;
var TicketState;
(function (TicketState) {
    TicketState[TicketState["InQueue"] = "inqueue"] = "InQueue";
    TicketState[TicketState["Processing"] = "processing"] = "Processing";
    TicketState[TicketState["Processed"] = "processed"] = "Processed";
    TicketState[TicketState["Skipped"] = "skipped"] = "Skipped";
    TicketState[TicketState["Failed"] = "failed"] = "Failed";
})(TicketState || (exports.TicketState = TicketState = {}));
//# sourceMappingURL=ticketState.js.map