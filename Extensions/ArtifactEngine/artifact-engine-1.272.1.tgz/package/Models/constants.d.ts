export declare class Constants {
    static DestinationUrlKey: string;
}
