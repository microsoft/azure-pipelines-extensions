"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ItemType = void 0;
var ItemType;
(function (ItemType) {
    ItemType[ItemType["Any"] = "any"] = "Any";
    ItemType[ItemType["Folder"] = "folder"] = "Folder";
    ItemType[ItemType["File"] = "file"] = "File";
})(ItemType || (exports.ItemType = ItemType = {}));
//# sourceMappingURL=itemType.js.map