import * as stream from 'stream';
import { ArtifactItem, IArtifactProvider } from '../Models';
import { ArtifactItemStore } from '../Store/artifactItemStore';
import { WebClient } from './webClient';
import { IRequestHandler, IRequestOptions } from './typed-rest-client/Interfaces';
export declare class WebProvider implements IArtifactProvider {
    artifactItemStore: ArtifactItemStore;
    constructor(rootItemsLocation: any, templateFile: string, variables: any, handler: IRequestHandler, requestOptions?: IRequestOptions);
    getRootItems(): Promise<ArtifactItem[]>;
    getArtifactItems(artifactItem: ArtifactItem): Promise<ArtifactItem[]>;
    getArtifactItem(artifactItem: ArtifactItem): Promise<NodeJS.ReadableStream>;
    putArtifactItem(item: ArtifactItem, readStream: stream.Readable): Promise<ArtifactItem>;
    dispose(): void;
    private getItems;
    private getTemplateFilePath;
    private extend;
    private rootItemsLocation;
    private templateFile;
    private variables;
    private requestCompressionForDownloads;
    webClient: WebClient;
}
