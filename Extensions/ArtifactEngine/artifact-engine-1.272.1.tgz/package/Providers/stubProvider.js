"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StubProvider = void 0;
const Stream = require("stream");
const models = require("../Models");
const Models_1 = require("../Models");
class StubProvider {
    constructor() {
        this.getArtifactItemCalledCount = 0;
        this.getArtifactItemsCalledCount = 0;
        this.getRootItemsCalledCount = 0;
        this.itemsDownloaded = [];
        this.itemsUploaded = {};
    }
    getRootItems() {
        return __awaiter(this, void 0, void 0, function* () {
            this.getRootItemsCalledCount++;
            return [this.getItem(1, 1, 3, Models_1.ItemType.File), this.getItem(1, 2, 3, Models_1.ItemType.File), this.getItem(1, 3, 3, Models_1.ItemType.File), this.getItem(2, 1, 1, Models_1.ItemType.Folder), this.getItem(3, 1, 5, Models_1.ItemType.File), this.getItem(4, 1, 3, Models_1.ItemType.File), this.getItem(5, 1, 4, Models_1.ItemType.Folder)];
        });
    }
    getArtifactItems(artifactItem) {
        return __awaiter(this, void 0, void 0, function* () {
            this.getArtifactItemsCalledCount++;
            if (artifactItem.path === 'path5') {
                return [this.getItem(5, 1, 2, Models_1.ItemType.File)];
            }
            return [];
        });
    }
    getArtifactItem(artifactItem) {
        return __awaiter(this, void 0, void 0, function* () {
            this.getArtifactItemCalledCount++;
            this.itemsDownloaded.push(artifactItem);
            yield this.delay(artifactItem.fileLength * 100);
            const s = new Stream.Readable();
            s._read = () => { };
            s.push(`stub content for ${artifactItem.path}`);
            s.push(null);
            return s;
        });
    }
    getItem(index, subIndex, length, itemType) {
        const artifactItem = new models.ArtifactItem();
        const path = itemType === Models_1.ItemType.File ? `path${index}\\path${subIndex}\\file${index}` : `path${index}`;
        artifactItem.path = path;
        artifactItem.fileLength = length;
        artifactItem.itemType = itemType;
        artifactItem.metadata = {};
        return artifactItem;
    }
    putArtifactItem(item, readStream) {
        var promise = new Promise((resolve, reject) => {
            var data = '';
            if (item.itemType === models.ItemType.File) {
                readStream.on('data', (chunk) => {
                    data += chunk;
                });
                readStream.on('end', () => {
                    this.itemsUploaded[item.path] = data;
                    resolve(item);
                });
                readStream.on('error', () => {
                    reject(item);
                });
            }
            else {
                resolve(item);
            }
        });
        return promise;
    }
    dispose() {
    }
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}
exports.StubProvider = StubProvider;
//# sourceMappingURL=stubProvider.js.map