"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUrl = getUrl;
const url = require("url");
function getUrl(requestUrl, baseUrl) {
    if (!baseUrl) {
        return requestUrl;
    }
    let base = url.parse(baseUrl);
    let combined = url.parse(requestUrl);
    combined.protocol = combined.protocol || base.protocol;
    combined.auth = combined.auth || base.auth;
    combined.host = combined.host || base.host;
    let res = url.format(combined);
    return res;
}
//# sourceMappingURL=Util.js.map