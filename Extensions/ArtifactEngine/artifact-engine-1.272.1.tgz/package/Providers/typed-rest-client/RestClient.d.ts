import httpm = require('./HttpClient');
import ifm = require("./Interfaces");
export interface IRestResponse<T> {
    statusCode: number;
    result: T;
}
export interface IRequestOptions {
    acceptHeader?: string;
    additionalHeaders?: ifm.IHeaders;
    responseProcessor?: Function;
}
export declare class RestClient {
    client: httpm.HttpClient;
    versionParam: string;
    constructor(userAgent: string, baseUrl?: string, handlers?: ifm.IRequestHandler[], requestOptions?: ifm.IRequestOptions);
    private _baseUrl;
    options<T>(requestUrl: string, options?: IRequestOptions): Promise<IRestResponse<T>>;
    get<T>(requestUrl: string, options?: IRequestOptions): Promise<IRestResponse<T>>;
    del<T>(requestUrl: string, options?: IRequestOptions): Promise<IRestResponse<T>>;
    create<T>(requestUrl: string, resources: any, options?: IRequestOptions): Promise<IRestResponse<T>>;
    update<T>(requestUrl: string, resources: any, options?: IRequestOptions): Promise<IRestResponse<T>>;
    replace<T>(requestUrl: string, resources: any, options?: IRequestOptions): Promise<IRestResponse<T>>;
    uploadStream<T>(verb: string, requestUrl: string, stream: NodeJS.ReadableStream, options?: IRequestOptions): Promise<IRestResponse<T>>;
    private _headersFromOptions;
    private _processResponse;
}
