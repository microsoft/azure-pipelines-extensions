"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RestClient = void 0;
const httpm = require("./HttpClient");
const util = require("./Util");
class RestClient {
    constructor(userAgent, baseUrl, handlers, requestOptions) {
        this.client = new httpm.HttpClient(userAgent, handlers, requestOptions);
        if (baseUrl) {
            this._baseUrl = baseUrl;
        }
    }
    options(requestUrl, options) {
        return __awaiter(this, void 0, void 0, function* () {
            let url = util.getUrl(requestUrl, this._baseUrl);
            let res = yield this.client.options(url, this._headersFromOptions(options));
            return this._processResponse(res, options);
        });
    }
    get(requestUrl, options) {
        return __awaiter(this, void 0, void 0, function* () {
            let url = util.getUrl(requestUrl, this._baseUrl);
            let res = yield this.client.get(url, this._headersFromOptions(options));
            return this._processResponse(res, options);
        });
    }
    del(requestUrl, options) {
        return __awaiter(this, void 0, void 0, function* () {
            let url = util.getUrl(requestUrl, this._baseUrl);
            let res = yield this.client.del(url, this._headersFromOptions(options));
            return this._processResponse(res, options);
        });
    }
    create(requestUrl, resources, options) {
        return __awaiter(this, void 0, void 0, function* () {
            let url = util.getUrl(requestUrl, this._baseUrl);
            let headers = this._headersFromOptions(options, true);
            let data = JSON.stringify(resources, null, 2);
            let res = yield this.client.post(url, data, headers);
            return this._processResponse(res, options);
        });
    }
    update(requestUrl, resources, options) {
        return __awaiter(this, void 0, void 0, function* () {
            let url = util.getUrl(requestUrl, this._baseUrl);
            let headers = this._headersFromOptions(options, true);
            let data = JSON.stringify(resources, null, 2);
            let res = yield this.client.patch(url, data, headers);
            return this._processResponse(res, options);
        });
    }
    replace(requestUrl, resources, options) {
        return __awaiter(this, void 0, void 0, function* () {
            let url = util.getUrl(requestUrl, this._baseUrl);
            let headers = this._headersFromOptions(options, true);
            let data = JSON.stringify(resources, null, 2);
            let res = yield this.client.put(url, data, headers);
            return this._processResponse(res, options);
        });
    }
    uploadStream(verb, requestUrl, stream, options) {
        return __awaiter(this, void 0, void 0, function* () {
            let url = util.getUrl(requestUrl, this._baseUrl);
            let headers = this._headersFromOptions(options, true);
            let res = yield this.client.sendStream(verb, url, stream, headers);
            return this._processResponse(res, options);
        });
    }
    _headersFromOptions(options, contentType) {
        options = options || {};
        let headers = options.additionalHeaders || {};
        headers["Accept"] = options.acceptHeader || "application/json";
        if (contentType) {
            headers["Content-Type"] = headers["Content-Type"] || 'application/json; charset=utf-8';
        }
        return headers;
    }
    _processResponse(res, options) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                let rres = {};
                let statusCode = res.message.statusCode;
                rres.statusCode = statusCode;
                if (statusCode == httpm.HttpCodes.NotFound) {
                    resolve(rres);
                }
                let obj;
                try {
                    let contents = yield res.readBody();
                    if (contents && contents.length > 0) {
                        obj = JSON.parse(contents);
                        if (options && options.responseProcessor) {
                            rres.result = options.responseProcessor(obj);
                        }
                        else {
                            rres.result = obj;
                        }
                    }
                }
                catch (err) {
                }
                if (statusCode > 299) {
                    let msg;
                    if (obj && obj.message) {
                        msg = obj.message;
                    }
                    else {
                        msg = "Failed request: (" + statusCode + ")";
                    }
                    let err = new Error(msg);
                    err['statusCode'] = statusCode;
                    if (rres.result) {
                        err['result'] = rres.result;
                    }
                    reject(err);
                }
                else {
                    resolve(rres);
                }
            }));
        });
    }
}
exports.RestClient = RestClient;
//# sourceMappingURL=RestClient.js.map