"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NtlmCredentialHandler = void 0;
const http = require("http");
const https = require("https");
var _ = require("underscore");
var ntlm = require("../opensource/node-http-ntlm/ntlm");
class NtlmCredentialHandler {
    constructor(username, password, domain, workstation) {
        this.username = username;
        this.password = password;
        if (domain !== undefined) {
            this.domain = domain;
        }
        if (workstation !== undefined) {
            this.workstation = workstation;
        }
    }
    prepareRequest(options) {
        if (options.agent) {
            delete options.agent;
        }
    }
    canHandleAuthentication(res) {
        if (res && res.statusCode === 401) {
            var wwwAuthenticate = res.headers['www-authenticate'];
            if (wwwAuthenticate !== undefined) {
                var mechanisms = wwwAuthenticate.split(', ');
                var idx = mechanisms.indexOf("NTLM");
                if (idx >= 0) {
                    if (mechanisms[idx].length == 4) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    handleAuthentication(httpClient, protocol, options, objs, finalCallback) {
        var ntlmOptions = _.extend(options, {
            username: this.username,
            password: this.password,
            domain: this.domain || '',
            workstation: this.workstation || ''
        });
        var keepaliveAgent;
        if (httpClient.isSsl === true) {
            keepaliveAgent = new https.Agent({});
        }
        else {
            keepaliveAgent = new http.Agent({ keepAlive: true });
        }
        let self = this;
        this.sendType1Message(httpClient, protocol, ntlmOptions, objs, keepaliveAgent, function (err, res) {
            if (err) {
                return finalCallback(err, null, null);
            }
            setImmediate(function () {
                self.sendType3Message(httpClient, protocol, ntlmOptions, objs, keepaliveAgent, res, finalCallback);
            });
        });
    }
    sendType1Message(httpClient, protocol, options, objs, keepaliveAgent, callback) {
        var type1msg = ntlm.createType1Message(options);
        var type1options = {
            headers: {
                'Connection': 'keep-alive',
                'Authorization': type1msg
            },
            timeout: options.timeout || 0,
            agent: keepaliveAgent,
            allowRedirects: false
        };
        type1options = _.extend(type1options, _.omit(options, 'headers'));
        httpClient.requestInternal(protocol, type1options, objs, callback);
    }
    sendType3Message(httpClient, protocol, options, objs, keepaliveAgent, res, callback) {
        if (!res.headers['www-authenticate']) {
            return callback(new Error('www-authenticate not found on response of second request'));
        }
        var type2msg = ntlm.parseType2Message(res.headers['www-authenticate']);
        var type3msg = ntlm.createType3Message(type2msg, options);
        var type3options = {
            headers: {
                'Authorization': type3msg
            },
            allowRedirects: false,
            agent: keepaliveAgent
        };
        type3options.headers = _.extend(type3options.headers, options.headers);
        type3options = _.extend(type3options, _.omit(options, 'headers'));
        httpClient.requestInternal(protocol, type3options, objs, callback);
    }
}
exports.NtlmCredentialHandler = NtlmCredentialHandler;
//# sourceMappingURL=ntlm.js.map