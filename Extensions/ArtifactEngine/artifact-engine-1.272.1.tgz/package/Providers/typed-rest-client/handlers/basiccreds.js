"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BasicCredentialHandler = void 0;
class BasicCredentialHandler {
    constructor(username, password) {
        this.username = username;
        this.password = password;
    }
    prepareRequest(options) {
        options.headers['Authorization'] = 'Basic ' + Buffer.from(this.username + ':' + this.password, 'utf8').toString('base64');
        options.headers['X-TFS-FedAuthRedirect'] = 'Suppress';
    }
    canHandleAuthentication(res) {
        return false;
    }
    handleAuthentication(httpClient, protocol, options, objs, finalCallback) {
    }
}
exports.BasicCredentialHandler = BasicCredentialHandler;
//# sourceMappingURL=basiccreds.js.map