import ifm = require('../Interfaces');
export declare class PersonalAccessTokenCredentialHandler implements ifm.IRequestHandler {
    token: string;
    constructor(token: string);
    prepareRequest(options: any): void;
    canHandleAuthentication(res: ifm.IHttpResponse): boolean;
    handleAuthentication(httpClient: any, protocol: any, options: any, objs: any, finalCallback: any): void;
}
