import ifm = require('../Interfaces');
export declare class BasicCredentialHandler implements ifm.IRequestHandler {
    username: string;
    password: string;
    constructor(username: string, password: string);
    prepareRequest(options: any): void;
    canHandleAuthentication(res: ifm.IHttpResponse): boolean;
    handleAuthentication(httpClient: any, protocol: any, options: any, objs: any, finalCallback: any): void;
}
