import ifm = require('../Interfaces');
export declare class NtlmCredentialHandler implements ifm.IRequestHandler {
    username: string;
    password: string;
    workstation: string;
    domain: string;
    constructor(username: string, password: string, domain?: string, workstation?: string);
    prepareRequest(options: any): void;
    canHandleAuthentication(res: ifm.IHttpResponse): boolean;
    handleAuthentication(httpClient: any, protocol: any, options: any, objs: any, finalCallback: any): void;
    private sendType1Message;
    private sendType3Message;
}
