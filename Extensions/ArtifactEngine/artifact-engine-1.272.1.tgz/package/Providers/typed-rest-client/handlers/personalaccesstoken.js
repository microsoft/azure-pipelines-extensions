"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PersonalAccessTokenCredentialHandler = void 0;
class PersonalAccessTokenCredentialHandler {
    constructor(token) {
        this.token = token;
    }
    prepareRequest(options) {
        options.headers['Authorization'] = 'Basic ' + Buffer.from('PAT:' + this.token, 'utf8').toString('base64');
        options.headers['X-TFS-FedAuthRedirect'] = 'Suppress';
    }
    canHandleAuthentication(res) {
        return false;
    }
    handleAuthentication(httpClient, protocol, options, objs, finalCallback) {
    }
}
exports.PersonalAccessTokenCredentialHandler = PersonalAccessTokenCredentialHandler;
//# sourceMappingURL=personalaccesstoken.js.map