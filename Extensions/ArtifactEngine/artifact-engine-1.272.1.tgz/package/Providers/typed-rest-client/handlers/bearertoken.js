"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BearerCredentialHandler = void 0;
class BearerCredentialHandler {
    constructor(token) {
        this.token = token;
    }
    prepareRequest(options) {
        options.headers['Authorization'] = 'Bearer ' + this.token;
        options.headers['X-TFS-FedAuthRedirect'] = 'Suppress';
    }
    canHandleAuthentication(res) {
        return false;
    }
    handleAuthentication(httpClient, protocol, options, objs, finalCallback) {
    }
}
exports.BearerCredentialHandler = BearerCredentialHandler;
//# sourceMappingURL=bearertoken.js.map