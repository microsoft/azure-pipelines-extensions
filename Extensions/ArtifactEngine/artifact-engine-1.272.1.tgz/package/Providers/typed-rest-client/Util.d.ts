export declare function getUrl(requestUrl: string, baseUrl?: string): string;
