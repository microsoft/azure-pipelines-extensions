"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FilesystemProvider = void 0;
const path = require("path");
const fs = require("fs");
const models = require("../Models");
const logger_1 = require("../Engine/logger");
var tl = require('azure-pipelines-task-lib');
class FilesystemProvider {
    constructor(rootLocation, rootItemPath) {
        this._rootLocation = rootLocation;
        this._rootItemPath = rootItemPath ? rootItemPath : '';
    }
    getRootItems() {
        var rootItem = new models.ArtifactItem();
        rootItem.metadata = { downloadUrl: this._rootLocation };
        rootItem.path = this._rootItemPath;
        rootItem.itemType = models.ItemType.Folder;
        return Promise.resolve([rootItem]);
    }
    getArtifactItems(artifactItem) {
        var itemsPath = artifactItem.metadata["downloadUrl"];
        return this.getItems(itemsPath, artifactItem.path);
    }
    getArtifactItem(artifactItem) {
        var promise = new Promise((resolve, reject) => {
            var itemPath = artifactItem.metadata['downloadUrl'];
            try {
                var contentStream = fs.createReadStream(itemPath);
                contentStream.on('end', () => {
                    this.artifactItemStore.updateDownloadSize(artifactItem, contentStream.bytesRead);
                });
                contentStream.on("error", (error) => {
                    reject(error);
                });
                resolve(contentStream);
            }
            catch (error) {
                reject(error);
            }
        });
        return promise;
    }
    putArtifactItem(item, stream) {
        return new Promise((resolve, reject) => {
            const outputItemPath = path.join(this._rootLocation, item.path);
            if (item.itemType === models.ItemType.File) {
                const folder = path.dirname(outputItemPath);
                try {
                    tl.mkdirP(folder);
                    logger_1.Logger.logMessage(tl.loc("DownloadingTo", item.path, outputItemPath));
                    const outputStream = fs.createWriteStream(outputItemPath);
                    stream.pipe(outputStream);
                    stream.on("end", () => {
                        logger_1.Logger.logMessage(tl.loc("DownloadedTo", item.path, outputItemPath));
                        if (!item.metadata) {
                            item.metadata = {};
                        }
                        item.metadata[models.Constants.DestinationUrlKey] = outputItemPath;
                    });
                    stream.on("error", (error) => {
                        reject(error);
                    });
                    outputStream.on("finish", () => {
                        this.artifactItemStore.updateFileSize(item, outputStream.bytesWritten);
                        resolve(item);
                    });
                }
                catch (err) {
                    reject(err);
                }
            }
            else {
                try {
                    tl.mkdirP(outputItemPath);
                    resolve(item);
                }
                catch (err) {
                    reject(err);
                }
            }
        });
    }
    dispose() {
    }
    getItems(itemsPath, parentRelativePath) {
        var promise = new Promise((resolve, reject) => {
            var items = [];
            fs.readdir(itemsPath, (error, files) => {
                if (!!error) {
                    logger_1.Logger.logMessage(tl.loc("UnableToReadDirectory", itemsPath, error));
                    reject(error);
                    return;
                }
                for (var index = 0; index < files.length; index++) {
                    var file = files[index];
                    var filePath = path.join(itemsPath, file);
                    var itemStat;
                    try {
                        itemStat = fs.lstatSync(filePath);
                    }
                    catch (error) {
                        reject(error);
                        return;
                    }
                    var item = {
                        itemType: itemStat.isFile() ? models.ItemType.File : models.ItemType.Folder,
                        path: parentRelativePath ? path.join(parentRelativePath, file) : file,
                        fileLength: itemStat.size,
                        lastModified: itemStat.mtime,
                        contentType: undefined,
                        metadata: { "downloadUrl": filePath }
                    };
                    items = items.concat(item);
                }
                resolve(items);
            });
        });
        return promise;
    }
}
exports.FilesystemProvider = FilesystemProvider;
//# sourceMappingURL=filesystemProvider.js.map