import * as models from '../Models';
import { ArtifactItemStore } from '../Store/artifactItemStore';
export declare class FilesystemProvider implements models.IArtifactProvider {
    artifactItemStore: ArtifactItemStore;
    constructor(rootLocation: string, rootItemPath?: string);
    getRootItems(): Promise<models.ArtifactItem[]>;
    getArtifactItems(artifactItem: models.ArtifactItem): Promise<models.ArtifactItem[]>;
    getArtifactItem(artifactItem: models.ArtifactItem): Promise<NodeJS.ReadableStream>;
    putArtifactItem(item: models.ArtifactItem, stream: NodeJS.ReadableStream): Promise<models.ArtifactItem>;
    dispose(): void;
    private getItems;
    private _rootLocation;
    private _rootItemPath;
}
