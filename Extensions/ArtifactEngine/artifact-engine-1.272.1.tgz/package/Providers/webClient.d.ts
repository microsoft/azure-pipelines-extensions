import * as httpm from './typed-rest-client/HttpClient';
export declare class WebClient {
    private httpc;
    constructor(handlers: any, options: any);
    get(requestUrl: string, additionalHeaders?: any): Promise<httpm.HttpClientResponse>;
    dispose(): void;
    processResponse(res: httpm.HttpClientResponse): Promise<void>;
}
