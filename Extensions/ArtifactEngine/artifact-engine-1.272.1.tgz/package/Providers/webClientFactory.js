"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebClientFactory = void 0;
const fs = require("fs");
const crypto = require("crypto");
const webClient_1 = require("./webClient");
class WebClientFactory {
    static getClient(handlers, options) {
        options = options || {};
        options.keepAlive = true;
        this.initializeProxy(options);
        return new webClient_1.WebClient(handlers, options);
    }
    static initializeProxy(options) {
        if (!options.proxy || !options.proxy.proxyUrl) {
            if (global['_vsts_task_lib_proxy']) {
                let proxyFromEnv = {
                    proxyUrl: global['_vsts_task_lib_proxy_url'],
                    proxyUsername: global['_vsts_task_lib_proxy_username'],
                    proxyPassword: this._readTaskLibSecrets(global['_vsts_task_lib_proxy_password']),
                    proxyBypassHosts: JSON.parse(global['_vsts_task_lib_proxy_bypass'] || "[]"),
                };
                options.proxy = proxyFromEnv;
            }
        }
        if (!options.cert) {
            if (global['_vsts_task_lib_cert']) {
                let certFromEnv = {
                    caFile: global['_vsts_task_lib_cert_ca'],
                    certFile: global['_vsts_task_lib_cert_clientcert'],
                    keyFile: global['_vsts_task_lib_cert_key'],
                    passphrase: this._readTaskLibSecrets(global['_vsts_task_lib_cert_passphrase']),
                };
                options.cert = certFromEnv;
            }
        }
        if (!options.ignoreSslError) {
            options.ignoreSslError = !!global['_vsts_task_lib_skip_cert_validation'];
        }
    }
    static _readTaskLibSecrets(lookupKey) {
        if (lookupKey && lookupKey.indexOf(':') > 0) {
            let lookupInfo = lookupKey.split(':', 2);
            let keyFile = Buffer.from(lookupInfo[0], 'base64').toString('utf8');
            let encryptKey = Buffer.from(fs.readFileSync(keyFile, 'utf8'), 'base64');
            let encryptedContent = Buffer.from(lookupInfo[1], 'base64').toString('utf8');
            const key = encryptKey.length === 32 ? encryptKey : crypto.createHash('sha256').update(encryptKey).digest();
            const iv = Buffer.alloc(16, 0);
            let decipher = crypto.createDecipheriv("aes-256-ctr", key, iv);
            let decryptedContent = decipher.update(encryptedContent, 'hex', 'utf8');
            decryptedContent += decipher.final('utf8');
            return decryptedContent;
        }
    }
}
exports.WebClientFactory = WebClientFactory;
//# sourceMappingURL=webClientFactory.js.map