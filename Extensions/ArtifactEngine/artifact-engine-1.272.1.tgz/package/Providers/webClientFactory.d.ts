export declare class WebClientFactory {
    static getClient(handlers: any[], options: any): any;
    private static initializeProxy;
    private static _readTaskLibSecrets;
}
