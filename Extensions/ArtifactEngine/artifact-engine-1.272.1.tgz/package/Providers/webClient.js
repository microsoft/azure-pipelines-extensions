"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebClient = void 0;
const httpm = require("./typed-rest-client/HttpClient");
var tl = require('azure-pipelines-task-lib/task');
var packagejson = require('../package.json');
class WebClient {
    constructor(handlers, options) {
        this.httpc = new httpm.HttpClient('artifact-engine ' + packagejson.version, handlers, options);
    }
    get(requestUrl, additionalHeaders) {
        var promise = new Promise((resolve, reject) => {
            this.httpc.get(requestUrl, additionalHeaders).then((res) => {
                this.processResponse(res).then(() => {
                    resolve(res);
                }, (err) => {
                    reject(err);
                });
            }, (err) => {
                reject(err);
            });
        });
        return promise;
    }
    dispose() {
        this.httpc.dispose();
    }
    processResponse(res) {
        return __awaiter(this, void 0, void 0, function* () {
            const statusCode = res.message.statusCode;
            let err;
            if (statusCode > 299) {
                let obj;
                var msg = tl.loc("FailedRequest", statusCode);
                err = new Error(msg);
                err['statusCode'] = statusCode;
                try {
                    let result = yield res.readBody();
                    err['result'] = result;
                }
                catch (error) {
                }
            }
            if (!!err) {
                throw err;
            }
        });
    }
}
exports.WebClient = WebClient;
//# sourceMappingURL=webClient.js.map