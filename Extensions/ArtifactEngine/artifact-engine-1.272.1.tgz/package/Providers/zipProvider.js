"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ZipProvider = void 0;
const Models_1 = require("../Models");
const factory = require("./webClientFactory");
class ZipProvider {
    constructor(zipLocation, handler, requestOptions) {
        this.zipLocation = zipLocation;
        this.webClient = factory.WebClientFactory.getClient([handler], requestOptions);
    }
    getRootItems() {
        var rootItem = new Models_1.ArtifactItem();
        rootItem.metadata = { downloadUrl: this.zipLocation };
        rootItem.path = '';
        rootItem.itemType = Models_1.ItemType.File;
        return Promise.resolve([rootItem]);
    }
    getArtifactItems(artifactItem) {
        return null;
    }
    getArtifactItem(artifactItem) {
        var promise = new Promise((resolve, reject) => {
            if (!artifactItem.metadata || !artifactItem.metadata['downloadUrl']) {
                reject("No downloadUrl available to download the item.");
            }
            var downloadSize = 0;
            var itemUrl = artifactItem.metadata['downloadUrl'];
            itemUrl = itemUrl.replace(/([^:]\/)\/+/g, "$1");
            this.webClient.get(itemUrl).then((res) => {
                res.message.on('data', (chunk) => {
                    if (chunk) {
                        downloadSize += chunk.length;
                    }
                });
                res.message.on('end', () => {
                    this.artifactItemStore.updateDownloadSize(artifactItem, downloadSize);
                });
                res.message.on('error', (error) => {
                    reject(error);
                });
                resolve(res.message);
            }, (reason) => {
                reject(reason);
            });
        });
        return promise;
    }
    putArtifactItem(artifactItem, stream) {
        return null;
    }
    dispose() {
    }
}
exports.ZipProvider = ZipProvider;
//# sourceMappingURL=zipProvider.js.map