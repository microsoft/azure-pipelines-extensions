"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebProvider = void 0;
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");
const Models_1 = require("../Models");
const logger_1 = require("../Engine/logger");
const webClientFactory_1 = require("./webClientFactory");
var handlebars = require('handlebars');
var tl = require('azure-pipelines-task-lib/task');
class WebProvider {
    constructor(rootItemsLocation, templateFile, variables, handler, requestOptions) {
        this.rootItemsLocation = rootItemsLocation;
        this.templateFile = templateFile;
        this.webClient = webClientFactory_1.WebClientFactory.getClient([handler], requestOptions);
        this.variables = variables;
        this.requestCompressionForDownloads = requestOptions ? requestOptions.requestCompressionForDownloads : false;
    }
    getRootItems() {
        var rootItem = new Models_1.ArtifactItem();
        rootItem.metadata = { downloadUrl: this.rootItemsLocation };
        rootItem.path = '';
        rootItem.itemType = Models_1.ItemType.Folder;
        return Promise.resolve([rootItem]);
    }
    getArtifactItems(artifactItem) {
        var itemsUrl = artifactItem.metadata["downloadUrl"];
        var contentType = artifactItem.contentType;
        return this.getItems(itemsUrl, contentType);
    }
    getArtifactItem(artifactItem) {
        var promise = new Promise((resolve, reject) => {
            if (!artifactItem.metadata || !artifactItem.metadata['downloadUrl']) {
                reject("No downloadUrl available to download the item.");
            }
            var downloadSize = 0;
            var contentType = artifactItem.contentType;
            var itemUrl = artifactItem.metadata['downloadUrl'];
            var zipStream = null;
            itemUrl = itemUrl.replace(/([^:]\/)\/+/g, "$1");
            const additionalHeaders = {};
            if (contentType) {
                additionalHeaders['Accept'] = contentType;
            }
            if (this.requestCompressionForDownloads) {
                additionalHeaders['Accept-Encoding'] = "gzip";
            }
            this.webClient.get(itemUrl, additionalHeaders).then((res) => {
                res.message.on('data', (chunk) => {
                    downloadSize += chunk.length;
                });
                res.message.on('end', () => {
                    this.artifactItemStore.updateDownloadSize(artifactItem, downloadSize);
                });
                res.message.on('error', (error) => {
                    if (zipStream) {
                        zipStream.destroy(error);
                        logger_1.Logger.logMessage(error.toString());
                    }
                    reject(error);
                });
                if (res.message.headers['content-encoding'] === 'gzip') {
                    try {
                        zipStream = zlib.createUnzip();
                        resolve(res.message.pipe(zipStream));
                    }
                    catch (err) {
                        reject(err);
                    }
                }
                else {
                    resolve(res.message);
                }
            }, (reason) => {
                reject(reason);
            });
        });
        return promise;
    }
    putArtifactItem(item, readStream) {
        throw new Error("Not implemented");
    }
    dispose() {
        this.webClient.dispose();
    }
    getItems(itemsUrl, contentType) {
        var promise = new Promise((resolve, reject) => {
            itemsUrl = itemsUrl.replace(/([^:]\/)\/+/g, "$1");
            this.webClient.get(itemsUrl, contentType ? { 'Accept': contentType } : { 'Accept': 'application/json' }).then((res) => {
                res.readBody().then((body) => {
                    fs.readFile(this.getTemplateFilePath(), 'utf8', (err, templateFileContent) => {
                        if (err) {
                            logger_1.Logger.logMessage(err ? JSON.stringify(err) : "");
                            reject(err);
                        }
                        try {
                            var template = handlebars.compile(templateFileContent);
                            var response = JSON.parse(body);
                            var context = this.extend(response, this.variables);
                            var result = template(context);
                            var items = JSON.parse(result);
                            resolve(items);
                        }
                        catch (error) {
                            logger_1.Logger.logMessage(tl.loc("FailedToParseResponse", body, error));
                            reject(error);
                        }
                    });
                }, (err) => {
                    reject(err);
                });
            }, (err) => {
                reject(err);
            });
        });
        return promise;
    }
    getTemplateFilePath() {
        return path.isAbsolute(this.templateFile) ? this.templateFile : path.join(__dirname, this.templateFile);
    }
    extend(target, source) {
        for (var prop in source) {
            target[prop] = source[prop];
        }
        return target;
    }
}
exports.WebProvider = WebProvider;
//# sourceMappingURL=webProvider.js.map