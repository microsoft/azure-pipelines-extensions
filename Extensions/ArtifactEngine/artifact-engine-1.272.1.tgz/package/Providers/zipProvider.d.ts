import { ArtifactItemStore } from '../Store/artifactItemStore';
import { ArtifactItem, IArtifactProvider } from '../Models';
import { WebClient } from './webClient';
import { IRequestHandler, IRequestOptions } from './typed-rest-client/Interfaces';
export declare class ZipProvider implements IArtifactProvider {
    artifactItemStore: ArtifactItemStore;
    constructor(zipLocation: any, handler: IRequestHandler, requestOptions?: IRequestOptions);
    getRootItems(): Promise<ArtifactItem[]>;
    getArtifactItems(artifactItem: ArtifactItem): Promise<ArtifactItem[]>;
    getArtifactItem(artifactItem: ArtifactItem): Promise<NodeJS.ReadableStream>;
    putArtifactItem(artifactItem: ArtifactItem, stream: NodeJS.ReadableStream): Promise<ArtifactItem>;
    dispose(): void;
    private zipLocation;
    webClient: WebClient;
}
