import * as models from '../Models';
import { ItemType } from '../Models';
import { ArtifactItemStore } from '../Store/artifactItemStore';
export declare class StubProvider implements models.IArtifactProvider {
    artifactItemStore: ArtifactItemStore;
    getArtifactItemCalledCount: number;
    getArtifactItemsCalledCount: number;
    getRootItemsCalledCount: number;
    itemsDownloaded: models.ArtifactItem[];
    itemsUploaded: {
        [item: string]: string;
    };
    getRootItems(): Promise<models.ArtifactItem[]>;
    getArtifactItems(artifactItem: models.ArtifactItem): Promise<models.ArtifactItem[]>;
    getArtifactItem(artifactItem: models.ArtifactItem): Promise<NodeJS.ReadableStream>;
    getItem(index: number, subIndex: number, length: number, itemType: ItemType): models.ArtifactItem;
    putArtifactItem(item: models.ArtifactItem, readStream: NodeJS.ReadableStream): Promise<models.ArtifactItem>;
    dispose(): void;
    delay(ms: number): Promise<{}>;
}
